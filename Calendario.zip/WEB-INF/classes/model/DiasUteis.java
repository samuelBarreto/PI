package model;

import java.util.Date;

public class DiasUteis {
	private Date dataInicial;
	private int diasUteis;
	private String ResultadoDias;
	
	
	public Date getDataInicial() {
		return dataInicial;
	}
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	public int getDiasUteis() {
		return diasUteis;
	}
	public void setDiasUteis(int diasUteis) {
		this.diasUteis = diasUteis;
	}
	public String getResultadoDias() {
		return ResultadoDias;
	}
	public void setResultadoDias(String resultadoDias) {
		ResultadoDias = resultadoDias;
	}
	

	
	}
